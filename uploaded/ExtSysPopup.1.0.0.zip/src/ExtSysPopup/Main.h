﻿// Main.hpp

#pragma once

//---------------------------------------------------------------------------//

BOOL CheckTopMost(HWND hwnd);
BOOL ToggleTopMost(HWND hwnd, BOOL topmost);
BOOL OpenAppFolder(HWND hwnd);

//---------------------------------------------------------------------------//

// Main.hpp